module GraphIO (writeGraphToFile) where

import Base
import qualified Data.Map as Map
import System.IO

-- Writes the graph to a file in a simple text format
-- Format:
-- NODE <NodeId> <Cost> <Term>
-- EDGE <FromNodeId> <ToNodeId>
writeGraphToFile :: FilePath -> Graph -> [(NodeId, NodeId)] -> IO ()
writeGraphToFile path graph edges = withFile path WriteMode $ \h -> do
    mapM_ (writeNode h) (Map.elems graph)
    mapM_ (writeEdge h) edges

-- Format: NODE <id> <cost> <term>
writeNode :: Handle -> Node -> IO ()
writeNode h (Node nid t c _) =
    hPutStrLn h $ unwords ["NODE", show nid, show c, show t]

-- Format: EDGE <from> <to>
writeEdge :: Handle -> (NodeId, NodeId) -> IO ()
writeEdge h (from, to) =
    hPutStrLn h $ unwords ["EDGE", show from, show to]
