{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE OverloadedStrings #-}

import Base
import GraphRewrite
import qualified Data.Map as Map
import Data.Aeson (decode, encode)
import qualified Data.ByteString.Lazy.Char8 as B
import GHC.Generics
import System.Environment

-- Add instances for serialization
import Data.Aeson (ToJSON, FromJSON)

instance ToJSON Term
instance FromJSON Term

instance ToJSON Node
instance FromJSON Node

instance ToJSON Rule
instance FromJSON Rule

type GraphJSON = Map.Map NodeId Node

main :: IO ()
main = do
    input <- B.getContents
    case decode input :: Maybe (GraphJSON, [Rule]) of
        Just (g, rules) -> B.putStrLn . encode $ rewriteGraphOnce rules g
        Nothing         -> error "Invalid input"
