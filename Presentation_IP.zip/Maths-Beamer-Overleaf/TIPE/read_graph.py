import json
import subprocess
import torch
from torch_geometric.data import Data
from gnn_model import GNNWrapper  
import numpy as np
from torch_geometric.data import Data

def rewrite_graph_via_haskell(graph_dict, rules_list):
    """
    Appelle le binaire Haskell 'rewrite' en passant le graphe et les règles via stdin (format JSON).
    Retourne le graphe modifié (après réécriture) lu depuis stdout.
    """
    process = subprocess.run(
        ["./rewrite"],
        input=json.dumps((graph_dict, rules_list)),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True
    )
    if process.returncode != 0:
        raise RuntimeError(f"Erreur Haskell : {process.stderr}")
    return json.loads(process.stdout)

def build_pyg_data(graph, num_rules):
    """
    Construit un objet Data de PyTorch Geometric à partir du graphe JSON :
    - x : vecteur [latence || score_init] pour chaque sommet
    - edge_index : arêtes du graphe
    """

    node_ids = list(graph.keys())
    node_map = {nid: i for i, nid in enumerate(node_ids)}

    x = []
    edges = []
    for nid, node in graph.items():
        latency = node.get('latency', 0.0)
        score_init = [0.0 for _ in range(num_rules)]  # à remplacer par des valeurs réelles
        x.append([latency] + score_init)
        # (Optionnel) Ajouter les voisins si structure de graphe disponible

    edge_index = torch.tensor(edges, dtype=torch.long).t().contiguous()
    x = torch.tensor(x, dtype=torch.float)

    return Data(x=x, edge_index=edge_index)

def run_gnn_on_graph(graph_json, num_rules):
    """
    Applique le modèle GNN sur le graphe donné, retourne un score pour chaque règle sur chaque sommet.
    """
    model = GNNWrapper(num_rules=num_rules)
    data = build_pyg_data(graph_json, num_rules)
    with torch.no_grad():
        scores = model(data)
    return scores  # forme : [nb_sommets, nb_règles]

if __name__ == "__main__":
   

    # Étape 1 : appel au programme Haskell pour la réécriture du graphe
    new_graph = rewrite_graph_via_haskell(dummy_graph, dummy_rules)
    print("Graphe après réécriture :", new_graph)

    # Étape 2 : application du GNN pour évaluer les scores de règles
    scores = run_gnn_on_graph(new_graph, num_rules=2)
    print("Scores GNN par sommet :\n", scores)
