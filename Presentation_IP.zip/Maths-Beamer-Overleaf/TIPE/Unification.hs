module Unification (unify, applySubst) where

import Base
import qualified Data.Map as Map
import Data.Maybe (fromMaybe)

-- Substitution : associe des variables à des termes
type Subst = Map.Map String Term

-- Application d'une substitution sur un terme
applySubst :: Subst -> Term -> Term
applySubst subst (Var x) = fromMaybe (Var x) (Map.lookup x subst)
applySubst subst (Fun f ts) = Fun f (map (applySubst subst) ts)

-- Unification naïve
unify :: Term -> Term -> Maybe Subst
unify (Var x) t = Just $ Map.singleton x t
unify t (Var x) = Just $ Map.singleton x t
unify (Fun f1 ts1) (Fun f2 ts2)
    | f1 == f2 && length ts1 == length ts2 = unifyArgs ts1 ts2
    | otherwise = Nothing
unify _ _ = Nothing

-- Unification d'une liste d'arguments
unifyArgs :: [Term] -> [Term] -> Maybe Subst
unifyArgs [] [] = Just Map.empty
unifyArgs (t1:ts1) (t2:ts2) = do
    s1 <- unify t1 t2
    s2 <- unifyArgs (map (applySubst s1) ts1) (map (applySubst s1) ts2)
    return (Map.union s2 s1)
unifyArgs _ _ = Nothing