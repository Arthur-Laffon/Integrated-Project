module Base where

import Data.Map (Map)
import qualified Data.Map as Map
import Data.List (intercalate)

-- Terme : arbre syntaxique typé
data Term = Var String
          | Fun String [Term]
          deriving (Eq, Ord)

instance Show Term where
    show (Var x) = x
    show (Fun f ts) = f ++ "(" ++ intercalate "," (map show ts) ++ ")"

-- Règle de réécriture
data Rule = Rule { lhs :: Term, rhs :: Term }
    deriving (Eq, Show)

-- Calcul de la hauteur du terme (utile pour rleft estimation)
termDepth :: Term -> Int
termDepth (Var _) = 1
termDepth (Fun _ ts) = 1 + maximum (0 : map termDepth ts)

-- Hauteur maximale du côté gauche d'une règle
ruleLeftDepth :: Rule -> Int
ruleLeftDepth (Rule l _) = termDepth l

-- Graphe d’exécution
type NodeId = Int
data Node = Node { nodeId :: NodeId, term :: Term, cost :: Float, latency :: Float }
    deriving (Show, Eq)

type Graph = Map NodeId Node
type RewriteSystem = [Rule]
