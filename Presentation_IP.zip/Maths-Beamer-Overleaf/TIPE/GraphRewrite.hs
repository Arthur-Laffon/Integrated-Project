module GraphRewrite (applyRuleToGraph, rewriteGraphOnce) where


import Base
import Scheduler
import Unification
import System.Random
import System.Random.Stateful (globalStdGen, uniformRM)
import qualified Data.Map as Map
import Control.Monad (replicateM)
import Data.Maybe (mapMaybe)

-- Applique une règle à tous les nœuds du graphe (modification locale)
applyRuleToGraph :: Rule -> Graph -> Graph
applyRuleToGraph rule graph = Map.map updateNode graph
  where
    updateNode node =
      case unify (lhs rule) (term node) of
        Just subst ->
          let newTerm = applySubst subst (rhs rule)
              newCost = estimateCost newTerm
          in node { term = newTerm, cost = newCost }
        Nothing -> node

-- Applique toutes les règles à chaque nœud une seule fois, dans l'ordre fourni
rewriteGraphOnce :: RewriteSystem -> Graph -> Graph
rewriteGraphOnce rules graph = Map.map rewriteNode graph
  where
    rewriteNode node =
      case tryRewrite (term node) of
        Just (t', c') -> node { term = t', cost = c' }
        Nothing -> node

    tryRewrite t = foldr tryRule Nothing rules
      where
        tryRule rule acc = case unify (lhs rule) t of
          Just subst -> let t' = applySubst subst (rhs rule)
                            c' = estimateCost t'
                        in Just (t', c')
          Nothing -> acc

-- Tire un flottant selon une distribution normale centrée en mu, écart-type sigma (Box-Muller)
randomNormal :: Float -> Float -> IO Float
randomNormal mu sigma = do
    u1 <- uniformRM (0.0, 1.0) globalStdGen
    u2 <- uniformRM (0.0, 1.0) globalStdGen
    let r = sqrt (-2 * log u1)
        theta = 2 * pi * u2
        z0 = r * cos theta
    return (mu + sigma * z0)

-- Applique une distribution normale au coût de chaque tâche puis simule son exécution
simulateExecutionCost :: Graph -> Int -> IO Float
simulateExecutionCost graph nThreads = do
    let nodeIds = Map.keys graph
    randomised <- mapM assignRandomCost nodeIds
    let updatedGraph = Map.fromList [(i, node { cost = c }) | (i, (node, c)) <- randomised]
        schedule = scheduleGraham updatedGraph nThreads
    return $ maximum [endTime t | t <- schedule]
  where
    assignRandomCost :: NodeId -> IO (NodeId, (Node, Float))
    assignRandomCost nid = do
      let node = graph Map.! nid
          mu = cost node
          sigma = mu / 3
      sampled <- randomNormal mu sigma
      return (nid, (node, max 0 sampled))  -- Pas de coût négatif
