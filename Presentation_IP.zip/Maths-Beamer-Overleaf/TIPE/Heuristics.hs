module Heuristics where

import Base
import Scheduler (scheduleGraham)
import GraphRewrite (applyRuleAtNode)
import System.Random
import qualified Data.Map as Map
import Data.List (maximumBy)
import Data.Ord (comparing)
import Control.Monad (replicateM)

-- Estimation du coût du graphe par simulation (1 run)
simulateExecutionCost :: Graph -> Int -> IO Float
simulateExecutionCost graph numThreads = do
    noisyGraph <- Map.traverseWithKey randomizeCost graph
    let schedule = scheduleGraham noisyGraph numThreads
    return $ maximum (map endTime schedule)

-- Bruit gaussien sur le coût d'un nœud
randomizeCost :: NodeId -> Node -> IO Node
randomizeCost _ node = do
    noise <- randomNormal 0 (cost node / 3)
    return node { cost = max 0.1 (cost node + noise) }

-- Générateur de gaussienne par Box-Muller
randomNormal :: Float -> Float -> IO Float
randomNormal mu sigma = do
    u1 <- randomRIO (1e-6, 1) -- éviter log(0)
    u2 <- randomRIO (0, 1)
    let z0 = sqrt (-2 * log u1) * cos (2 * pi * u2)
    return (mu + sigma * z0)

-- Score initial d’une règle à un nœud
scoreInit :: Rule -> NodeId -> Graph -> Int -> IO Float
scoreInit rule nid graph threads = do
    let t = cost (graph Map.! nid)
    case applyRuleAtNode rule nid graph of
        Nothing -> return 0
        Just g' -> do
            t' <- simulateExecutionCost g' threads
            return (t - t')

-- Score final = score init + α × (Δ scores sur voisins)
evaluateRuleScore
  :: Rule -> NodeId -> Graph -> Int -> Float -> IO Float
evaluateRuleScore rule nid graph threads alpha = do
    scoreInitBefore <- scoreInit rule nid graph threads
    case applyRuleAtNode rule nid graph of
        Nothing -> return (-1/0)  -- Règle non applicable
        Just graph' -> do
            let depth = ruleLeftDepth rule
                affected = neighborhood graph nid depth
            scoreBefore <- mapM (\i -> scoreInit rule i graph threads) affected
            scoreAfter  <- mapM (\i -> scoreInit rule i graph' threads) affected
            let delta = sum scoreAfter - sum scoreBefore
            return (scoreInitBefore + alpha * delta)

-- Donne les nœuds à distance ≤ d du nœud nid dans le graphe (par adjacency)
neighborhood :: Graph -> NodeId -> Int -> [NodeId]
neighborhood graph start dist = bfs [start] Set.empty dist
  where
    bfs [] _ _ = []
    bfs _ _ 0 = []
    bfs (x:xs) visited d
        | x `Set.member` visited = bfs xs visited d
        | otherwise =
            let neighbors = directNeighbors x
                visited' = Set.insert x visited
            in x : bfs (xs ++ neighbors) visited' (d - 1)

    -- Dépend de la structure du graphe : ici on suppose des ids voisins séquentiels (à adapter)
    directNeighbors n = filter (`Map.member` graph) [n-1, n+1]

-- Trouve la meilleure règle pour un sommet donné
bestRule
  :: [Rule] -> NodeId -> Graph -> Int -> Float -> IO (Maybe Rule)
bestRule rules nid graph threads alpha = do
    scored <- mapM (\r -> do
        s <- evaluateRuleScore r nid graph threads alpha
        return (r, s)) rules
    let applicable = filter (\(_, s) -> s > 0) scored
    return $ if null applicable then Nothing
             else Just $ fst $ maximumBy (comparing snd) applicable
