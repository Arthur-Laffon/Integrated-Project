module KnuthBendix (complete, normalizeTerm) where

import Base
import Unification
import Data.List (nub, sortBy)
import Data.Maybe (mapMaybe)

-- Normalise un terme avec un ensemble de règles
normalizeTerm :: RewriteSystem -> Term -> Term
normalizeTerm rules term = case applyRule rules term of
    Just t' -> normalizeTerm rules t'
    Nothing -> case term of
        Fun f args -> Fun f (map (normalizeTerm rules) args)
        _ -> term

-- Applique la première règle qui matche exactement
applyRule :: RewriteSystem -> Term -> Maybe Term
applyRule [] _ = Nothing
applyRule (Rule l r : rs) t
    | l == t = Just r
    | otherwise = applyRule rs t

-- Paires critiques : recouvrements entre deux règles
criticalPairs :: RewriteSystem -> [(Term, Term)]
criticalPairs rules =
    [ (normalizeTerm rules (applySubst sigma l1), normalizeTerm rules (applySubst sigma r2))
    | Rule l1 r1 <- rules
    , Rule l2 r2 <- rules
    , (ctx, subterm) <- subtermsWithContext l1
    , Just sigma <- [unify subterm l2]
    , let applied = applySubst sigma r2
    , let replaced = applySubst sigma (ctx applied)
    , replaced /= applySubst sigma r1
    ]

-- Décompose un terme en ses sous-termes avec contexte de remplacement
subtermsWithContext :: Term -> [(Term -> Term, Term)]
subtermsWithContext t = go t id
  where
    go (Var x) ctx = [(ctx, Var x)]
    go f@(Fun _ []) ctx = [(ctx, f)]
    go (Fun f args) ctx =
        let direct = [(ctx, Fun f args)]
            nested = [ go arg (\t' -> ctx (Fun f (replaceAt i t')))
                     | (i, arg) <- zip [0..] args ]
        in direct ++ concat nested

    replaceAt i t' = [ if j == i then t' else a | (j, a) <- zip [0..] args ]

-- Fonction principale : algorithme de complétion de Knuth-Bendix avec limite
complete :: (Term -> Term -> Ordering) -> Int -> [(Term, Term)] -> RewriteSystem
complete termOrder maxRules eqs = loop eqs []
  where
    loop [] rs = rs
    loop _ rs | length rs >= maxRules = rs
    loop ((s, t):es) rs =
        let (s', t') = (normalizeTerm rs s, normalizeTerm rs t)
            (greater, lesser) = case termOrder s' t' of
                                  LT -> (t', s')
                                  _  -> (s', t')
            newRule = Rule greater lesser
            rs' = newRule : filter ((/= greater) . lhs) rs
            rs'' = map (\r -> Rule (lhs r) (normalizeTerm rs' (rhs r))) rs'
            cps = criticalPairs rs''
            es' = nub (es ++ cps)
        in loop es' rs''
