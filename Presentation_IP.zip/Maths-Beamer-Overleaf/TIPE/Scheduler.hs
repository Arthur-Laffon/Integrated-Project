module Scheduler (scheduleGraham, TaskAssignment(..)) where

import Base
import qualified Data.Map as Map
import qualified Data.Set as Set
import Data.List (sortOn)
import Data.Ord (Down(..))

-- Attributions des tâches à un processeur avec temps de début et de fin
data TaskAssignment = TaskAssignment
    { taskId :: NodeId
    , processor :: Int
    , startTime :: Float
    , endTime :: Float
    } deriving (Show, Eq)

type Schedule = [TaskAssignment]

-- Met à jour la latence de chaque nœud
updateLatencies :: Graph -> Edges -> Int -> Graph
updateLatencies graph edges numThreads = 
    let schedule = scheduleGraham graph edges numThreads
        latencies = Map.fromList [(taskId a, startTime a) | a <- schedule]
    in Map.mapWithKey (\nid node ->
           case Map.lookup nid latencies of
             Just l -> node { latency = l }
             Nothing -> node
       ) graph


-- Construit les prédécesseurs à partir des dépendances implicites dans un graphe
computePredecessors :: Graph -> Map.Map NodeId [NodeId]
computePredecessors graph = Map.fromList [(n, []) | n <- Map.keys graph] -- À adapter si dépendances explicites

-- Ordonnancement glouton de Graham à partir d’un graphe d’exécution
scheduleGraham :: Graph -> Int -> Schedule
scheduleGraham graph m = go 0 [] initialReady [] Set.empty
  where
    preds = computePredecessors graph
    nodes = Map.keys graph
    initialReady = [n | n <- nodes, null (Map.findWithDefault [] n preds)]

    go _ _ [] acc _ | Map.size graph == length acc = acc
    go t busy ready acc done =
        let available = take (m - length busy) ready

            newlyStarted :: [(NodeId, Float, Float)]
            newlyStarted = [ (v, t, t + cost (graph Map.! v))
                           | v <- available ]

            processors :: [Int]
            processors = [0..]  -- indices de processeurs

            running :: [(NodeId, Float, Float, Int)]
            running = zipWith (\(vid, st, et) p -> (vid, st, et, p)) newlyStarted processors

            tasks :: [TaskAssignment]
            tasks = [ TaskAssignment vid p st et
                    | (vid, st, et, p) <- running ]

            busy' = [ (vid, et, p)
                    | (vid, _, et, p) <- running ] ++ busy

            tNext = minimum (map (\(_, et, _) -> et) busy')

            (finished, busy'') = span (\(_, et, _) -> et <= tNext) (sortOn (\(_, et, _) -> et) busy')

            done' = foldr (\(v, _, _) -> Set.insert v) done finished

            newReady = [ v
                       | v <- nodes
                       , all (`Set.member` done') (Map.findWithDefault [] v preds)
                       , v `notElem` map (\(vid, _, _) -> vid) busy''
                       , v `notElem` map taskId acc ]

            ready' = filter (`notElem` available) ready ++ newReady

        in go tNext busy'' ready' (acc ++ tasks) done'

